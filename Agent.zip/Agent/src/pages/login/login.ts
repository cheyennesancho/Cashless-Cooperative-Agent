import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController,Platform } from 'ionic-angular';

import { User } from '../../providers/user/user';
import { SignupPage } from '../signup/signup';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  // The account fields for the login form.
  // If you're using the username field with or without email, make
  // sure to add it to the type
  account: { email: string, password: string }= {
    email: '',
    password: ''
  } ;

  // Our translated text strings
  private agent_id : string;

  constructor(public navCtrl: NavController,
    public platform: Platform,

    public user: User,
    public toastCtrl: ToastController,
    ) {


  }


  // Attempt to login in through our User service
  doLogin() {
    let type = "?type=login&email=" + this.account.email + "&password=" + this.account.password;

    this.user.login(type).subscribe((resp: any) => {
      console.log(resp);
      if (resp.status) {
        this.agent_id = resp.agent.agent_id;
        this.navCtrl.setRoot(SignupPage ,{agent_id : this.agent_id } );
      } else {
        let toast = this.toastCtrl.create({
          message: "Check Username / Password ",
          duration: 3000,
          position: 'top'
        });
        toast.present();
      }

    }, (err) => {
      console.log(err);
      // Unable to log in
      let toast = this.toastCtrl.create({
        message: err.message,
        duration: 3000,
        position: 'top'
      });
      toast.present();
    });
  }

}
