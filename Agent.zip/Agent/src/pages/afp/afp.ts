import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import {User} from '../../providers/user/user';
import { SignupPage } from '../signup/signup';
/**
 * Generated class for the AfpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-afp',
  templateUrl: 'afp.html',
})
export class AfpPage {

  private email : string;
  private merchantid : string;
  private showFields : string = "";
  private agree : boolean = false;
  private agent_id : string;
  private info : {
    storeLoc : string,
    contractLength : string,
    pos : boolean,
    posName : string,
    posModel : string,
    posPaperSize : string,
    posPaperType : string,
    posPaperUsage : string,
    creditModel : string,
    creditName : string,
    creditPaperSize : string,
    creditPaperType : string,
    creditPaperUsage : string,
    pump : boolean,
    pumpPaperSize : string,
    pumpPaperType : string,
    pumpPaperUsage : string,
    pumpName : string,
    pumpModel : string,
    atm : boolean,
    atmName : "",
    atmModel : "",
    atmPaperSize : string,
    atmPaperType : string,
    atmPaperUsage : string,
    agreedTerms : string,
    merchantid : string
                  } = {
                    storeLoc : "",
                    contractLength : "",
                    pos : false,
                    posName : "",
                    posModel : "",
                    posPaperSize : "",
                    posPaperType : "",
                    posPaperUsage : "",
                    creditModel : "",
                    creditName : "",
                    creditPaperSize : "",
                    creditPaperType : "",
                    creditPaperUsage : "",
                    pump : false,
                    pumpPaperSize : "",
                    pumpPaperType : "",
                    pumpPaperUsage : "",
                    pumpName : "",
                    pumpModel : "",
                    atm : false,
                    atmName : "",
                    atmModel : "",
                    atmPaperSize : "",
                    atmPaperType : "",
                    atmPaperUsage : "",
                    agreedTerms : "",
                    merchantid : "",
                
                  }


  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public user : User,
              public toastCtrl : ToastController
            ) {

              this.merchantid = this.navParams.get('merchantid');
              this.agent_id = this.navParams.get('agent_id');

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AfpPage');
  }



  checkEmail(){
    if(this.email != ""){
      let type = "email=" + this.email;
      this.user.checkEmail(type).subscribe((res : any)=>{
        console.log(res);
        if(res.status == 1){
          this.merchantid = res.data;
        };
      });
    };
  };

  changeForm(place){
    if(place  == 'pos') {
        this.info.posPaperSize = "";
        this.info.posPaperType = "";
        this.info.posPaperUsage = "";
        this.info.posModel = "";
        this.info.posName = "";
    };
    if(place  == 'credit') {
      this.info.creditPaperSize = "";
      this.info.creditPaperType = "";
      this.info.creditPaperUsage = "";
      this.info.creditModel = "";
      this.info.creditName = "";
    };    
    if(place  == 'pump') {

      this.info.pumpPaperSize = "";
      this.info.pumpPaperType = "";
      this.info.pumpPaperUsage = "";
      this.info.pumpName = "";
      this.info.pumpModel = "";

    };    
    if(place  == 'atm') {
      this.info.atmPaperSize = "";
      this.info.atmPaperType = "";
      this.info.atmPaperUsage = "";
      this.info.atmModel = "";
      this.info.atmName = "";
    };
  }

  onSubmit(){
    this.info.merchantid = this.merchantid;

    let type = "type=signup" + 
          "&agent_id=" + this.agent_id +
          "&storeLoc=" + this.info.storeLoc +
          "&contractLength=" + this.info.contractLength +
          "&agreedTerms=" + this.info.agreedTerms+
          "&merchantid=" + this.info.merchantid+
          "&atmName=" + this.info.atmName + 
          "&atmModel=" + this.info.atmModel + 
          "&atmPaperSize=" + this.info.atmPaperSize+
          "&atmPaperType=" + this.info.atmPaperType +
          "&atmPaperUsage=" + this.info.atmPaperUsage+ 
          "&contractLength=" + this.info.contractLength + 
          "&creditPaperType=" + this.info.creditPaperType + 
          "&creditPaperUsage=" + this.info.creditPaperUsage +
          "&creditPaperSize=" + this.info.creditPaperSize +
          "&creditModel=" + this.info.creditModel +
          "&creditName=" + this.info.creditName +
          "&posName=" + this.info.posName +
          "&posModel=" + this.info.posModel +
          "&posPaperUsage=" + this.info.posPaperUsage +
          "&posPaperType=" + this.info.posPaperType +
          "&posPaperSize=" + this.info.posPaperSize +
          "&pumpPaperType=" + this.info.pumpPaperType + 
          "&pumpPaperUsage=" + this.info.pumpPaperUsage + 
          "&pumpPaperSize=" + this.info.pumpPaperSize + 
          "&pumpName=" + this.info.pumpName + 
          "&pumpModel=" + this.info.pumpModel;
     
      this.user.enrollPaper(type).subscribe((res : any)=>{
      console.log(res);
      if(res.status == 1 ){

      let toast = this.toastCtrl.create({
        message: 'Registration Success.',
        duration: 3000,
        position: 'bottom'
      });
      toast.present();  

      this.navCtrl.push(SignupPage, {merchantid : res.data , agent_id : this.agent_id});
    }
    });

  }

}
