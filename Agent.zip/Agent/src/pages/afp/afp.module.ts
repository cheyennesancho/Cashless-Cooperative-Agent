import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AfpPage } from './afp';

@NgModule({
  declarations: [
    AfpPage,
  ],
  imports: [
    IonicPageModule.forChild(AfpPage),
  ],
})
export class AfpPageModule {}
