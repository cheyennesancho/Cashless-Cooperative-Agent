import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController, NavParams } from 'ionic-angular';
import { Signup3Page } from '../signup3/signup3';
import { Signup4Page } from '../signup4/signup4';
import { User } from '../../providers/user/user';
/**
 * Generated class for the Signup2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup2',
  templateUrl: 'signup2.html',
})
export class Signup2Page {

  private merchantid : string;
  private email : string;
  private agent_id : string;
  private prefbool : boolean = false;
  private info : {
                  numLocations : number,
                  businessYears : number,
                  yearsOwned : number ,
                  swipedRatio : number,
                  keyedRatio : number,
                  avgTicket : number,
                  avgVol : number,
                  maxTicket : number,
                  productsSold : string,
                  machinePref : string,
                  machineName : string,
                  phnConn : string,
                  ipConn : string,
                  sqft : string,
                  landType : string,
                  lanlorName : string,
                  lanlorPhone : number,

                 } = {
                  numLocations : null,
                  businessYears : null,
                  yearsOwned : null,
                  swipedRatio : null,
                  keyedRatio : null,
                  avgTicket : null,
                  avgVol : null,
                  maxTicket : null,
                  productsSold : "",
                  machinePref : "",
                  machineName : "",
                  phnConn : "",
                  ipConn : "",
                  sqft : "",
                  landType : "",
                  lanlorName : "",
                  lanlorPhone : null,

                }

  constructor(public toastCtrl : ToastController, 
              public navCtrl: NavController,
              public user : User,
              public navParams: NavParams) {

   this.merchantid = this.navParams.get('merchantid');
   this.agent_id = this.navParams.get('agent_id');
   this.prefbool = false;

   console.log(this.info);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Signup2Page');
  }

  nextPage(){
    console.log(this.info);

    if( this.info.swipedRatio != null &&
        this.info.numLocations != null &&
        this.info.businessYears != null &&
        this.info.yearsOwned != null &&
        this.info.keyedRatio != null &&
        this.info.avgTicket != null &&
        this.info.avgVol != null &&
        this.info.maxTicket != null &&
        this.info.productsSold != "" &&
        this.info.machinePref != "" &&
        this.info.phnConn != ""  &&
        this.info.ipConn != "" &&
        this.info.sqft != "" &&
        this.info.landType != "" &&
        this.info.lanlorName != "" &&
        this.info.lanlorPhone != null
     ){
    console.log(this.merchantid);
    this.navCtrl.push('Signup3Page' , { info : this.info , merchantid : this.merchantid , agent_id : this.agent_id});
    }
    else {
      let toast = this.toastCtrl.create({
        message: 'Please fill all fields',
        duration: 3000,
        position: 'top'
      });
    toast.present();
    };
  };

  checkEmail(){
    if(this.email != ""){
      let type = "email=" + this.email;
      this.user.checkEmail(type).subscribe((res : any)=>{
        console.log(res);
        if(res.status == 1){
          this.merchantid = res.data;
        }
        else{
          let toast = this.toastCtrl.create({
            message: res.message,
            duration: 3000,
            position: 'top'
          });
        toast.present();              
        }
      });
    };
  };

  switchBool() {
    this.prefbool = !this.prefbool;
  }

}
