import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController  } from 'ionic-angular';
import { SignupPage } from '../signup/signup';
import { Signup2Page } from '../signup2/signup2';

/**
 * Generated class for the ToolPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tool',
  templateUrl: 'tool.html',
})
export class ToolPage {

  public total_fee;
  public total_amt;
  public total_num;
  public effect_rate;
  public freedom_rate;
  public freedom_fee;
  public avg_tkt;
  public sheep;
  public savings;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public alertCtrl : AlertController ,  
              ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ToolPage');
  }

  effect(){
    let freedom = {interest:0.1 , flatrate:0.1 , PCIFee : 5 , stmtFee: 5};

    this.effect_rate = (100*this.total_fee)/this.total_amt;
    this.effect_rate = parseFloat(this.effect_rate).toFixed(2);


    this.freedom_fee = this.total_num*freedom.flatrate + ((this.total_amt*freedom.interest)/100) + freedom.PCIFee + freedom.stmtFee;
    this.freedom_rate = (100*this.freedom_fee)/this.total_amt;
    this.freedom_rate = parseFloat(this.freedom_rate).toFixed(2);
    
    this.avg_tkt = this.total_amt/this.total_num;

    if(this.avg_tkt >= 20 && this.effect_rate <= 3.00) {
      this.sheep = "Good!";
    }
    else if (this.avg_tkt <=10 && this.effect_rate <= 6.00 )  {
      this.sheep = "Good!";
     
    }
    else {
      this.sheep = "Bad!"
    }
    if (this.sheep) {
    }
    console.log("total fee: " + this.total_fee );
    console.log("freedom fee :"+ this.freedom_fee);
    this.savings = this.total_fee - this.freedom_fee;
    this.savings = parseFloat(this.savings).toFixed(2);
    console.log(this.savings);
    
  }

}
