import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Signup3Page } from './signup3';

@NgModule({
  declarations: [
    Signup3Page,
  ],
  imports: [
    IonicPageModule.forChild(Signup3Page),
  ],
})
export class Signup3PageModule {}
