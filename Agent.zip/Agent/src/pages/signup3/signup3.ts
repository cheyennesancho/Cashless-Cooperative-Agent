import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController, NavParams } from 'ionic-angular';
import { Signup4Page } from '../signup4/signup4';

/**
 * Generated class for the Signup3Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup3',
  templateUrl: 'signup3.html',
})
export class Signup3Page {
  private info : any;
  private merchantid : any;
  private agent_id : string;
  public states : any = ["Alaska",
  "Alabama",
  "Arkansas",
  "American Samoa",
  "Arizona",
  "California",
  "Colorado",
  "Connecticut",
  "District of Columbia",
  "Delaware",
  "Florida",
  "Georgia",
  "Guam",
  "Hawaii",
  "Iowa",
  "Idaho",
  "Illinois",
  "Indiana",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Massachusetts",
  "Maryland",
  "Maine",
  "Michigan",
  "Minnesota",
  "Missouri",
  "Mississippi",
  "Montana",
  "North Carolina",
  " North Dakota",
  "Nebraska",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "Nevada",
  "New York",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Puerto Rico",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Virginia",
  "Virgin Islands",
  "Vermont",
  "Washington",
  "Wisconsin",
  "West Virginia",
  "Wyoming"]

  constructor(public toastCtrl : ToastController ,public navCtrl: NavController, public navParams: NavParams) {
    this.info = this.navParams.get('info');
    this.merchantid = this.navParams.get('merchantid');
    this.agent_id = this.navParams.get('agent_id');
    this.info.ownTitle = "";
    this.info.ownDOB = "";
    this.info.homePhn = null;
    this.info.homeAdd = "";
    this.info.homeCity = "";
    this.info.homeState = "";
    this.info.homeZip = null;
    //this.info.mailPref = "";
    this.info.yapa = null ;
    this.info.ownPercent = null;
    this.info.dl = "";
    this.info.stateId = "";
    console.log(this.info);
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad Signup3Page');

  }

  nextPage(){
    console.log(this.info);
    if(this.info.name != "" &&
    this.info.ownTitle != ""&&
    this.info.ownDOB != "" &&
    this.info.homePhn != null &&
    this.info.homeAdd != "" &&
    this.info.homeCity != "" &&
    this.info.homeState != "" &&
    this.info.homeZip != null &&
    //this.info.mailPref != "" &&
    this.info.yapa != null &&
    this.info.ownPercent != null &&
    this.info.dl != "" &&
    this.info.stateId != "" 

   ){
console.log(this.merchantid)
    this.navCtrl.push('Signup4Page' , { info : this.info , merchantid : this.merchantid , agent_id : this.agent_id});
  }
  else {
    let toast = this.toastCtrl.create({
      message: 'Please fill all fields',
      duration: 3000,
      position: 'top'
    });
  toast.present();

  }
  }

}
