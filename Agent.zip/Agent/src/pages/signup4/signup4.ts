import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpClient, HttpParams,HttpHeaders} from '@angular/common/http';
import { User } from '../../providers/user/user';
import { SignupPage } from '../signup/signup';
/**
 * Generated class for the Signup4Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup4',
  templateUrl: 'signup4.html',
})
export class Signup4Page {
  
  private info : any ;
  private merchantid : number;
  private agent_id : string;
  public states : any = ["Alaska",
  "Alabama",
  "Arkansas",
  "American Samoa",
  "Arizona",
  "California",
  "Colorado",
  "Connecticut",
  "District of Columbia",
  "Delaware",
  "Florida",
  "Georgia",
  "Guam",
  "Hawaii",
  "Iowa",
  "Idaho",
  "Illinois",
  "Indiana",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Massachusetts",
  "Maryland",
  "Maine",
  "Michigan",
  "Minnesota",
  "Missouri",
  "Mississippi",
  "Montana",
  "North Carolina",
  " North Dakota",
  "Nebraska",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "Nevada",
  "New York",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Puerto Rico",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Virginia",
  "Virgin Islands",
  "Vermont",
  "Washington",
  "Wisconsin",
  "West Virginia",
  "Wyoming"]

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public http: HttpClient,
              public user : User,
              public toastCtrl : ToastController) {

    this.info = this.navParams.get('info');
    this.merchantid = this.navParams.get('merchantid');
    this.agent_id = this.navParams.get('agent_id');

    this.info.ref1Name = "";
    this.info.ref1Contact = "";
    this.info.ref1Add = "";
    this.info.ref1City = "";
    this.info.ref1State = "";
    this.info.ref1Zip = "";
    this.info.ref1Phn = null ;
    this.info.ref2Name = "" ;
    this.info.ref2Add = "" ;
    this.info.ref2City = "" ;
    this.info.ref2State = "" ;
    this.info.ref2Zip = "" ;
    this.info.ref2Contact = "";
    this.info.ref2Phn = null ;
    this.info.agreeTerms = false;
    this.info.merchantid = this.merchantid;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Signup4Page');
  }

  doSubmit(){
    console.log(this.info);
    if(    this.info.ref1Name != "" &&
    this.info.ref1Contact != "" &&
    this.info.ref1Add != "" &&
    this.info.ref1Phn != null &&
    this.info.ref2Name != "" &&
    this.info.ref2Add != "" &&
    this.info.ref2Contact != "" &&
    this.info.ref2Phn != null 
    ){

      let type = "type=signup&agreeTerms=" + this.info.agreeTerms +
      "&agent_id=" + this.agent_id +
      "&avgTicket=" + this.info.avgTicket +
      "&avgVol=" + this.info.avgVol +
      "&businessYears=" + this.info.businessYears +
      "&dl=" + this.info.dl + 
      "&homeAdd=" + this.info.homeAdd + 
      "&homeCity=" + this.info.homeCity + 
      "&homePhn=" + this.info.homePhn +
      "&homeState=" + this.info.homeState +
      "&homeZip=" + this.info.homeZip +
      "&ipConn=" + this.info.ipConn +
      "&keyedRatio=" + this.info.keyedRatio +
      "&landType=" + this.info.landType +
      "&lanlorName=" + this.info.lanlorName + 
      "&lanlorPhone=" + this.info.lanlorPhone + 
      "&machineName=" + this.info.machineName +
      "&machinePref=" + this.info.machinePref + 
      "&mailPref=" + this.info.mailPref +
      "&maxTicket=" + this.info.maxTicket +
      "&merchantid=" + this.info.merchantid +
      "&numLocations=" + this.info.numLocations +
      "&ownDOB=" + this.info.ownDOB + 
      "&ownPercent=" + this.info.ownPercent + 
      "&ownTitle=" + this.info.ownTitle + 
      "&phnConn=" + this.info.phnConn +
      "&ref1Add=" + this.info.ref1Add +
      "&ref1City=" + this.info.ref1City +
      "&ref1Contact=" + this.info.ref1Contact +
      "&ref1Name=" + this.info.ref1Name +
      "&ref1Phn=" + this.info.ref1Phn +
      "&ref1State=" + this.info.ref1State +
      "&ref1Zip=" + this.info.ref1Zip +
      "&ref2Add=" + this.info.ref2Add +
      "&ref2City=" + this.info.ref2City +
      "&ref2Contact=" + this.info.ref2Contact +
      "&ref2Name=" + this.info.ref2Name +
      "&ref2Phn=" + this.info.ref2Phn +
      "&ref2State=" + this.info.ref2State +
      "&ref2Zip=" + this.info.ref2Zip +
      "&sqft=" + this.info.sqft +
      "&stateId=" + this.info.stateId +
      "&swipedRatio=" + this.info.swipedRatio +
      "&yapa=" + this.info.yapa +
      "&yearsOwned=" + this.info.yearsOwned +
      "&productsSold=" + this.info.productsSold; 

      console.log(this.info.merchantid);
      this.user.Enrollservice(type).subscribe((res : any)=>{
        console.log(res);     
        if(res.status == 1 ){
      
         let toast = this.toastCtrl.create({
          message: 'Registration Success.',
          duration: 3000,
          position: 'bottom'
        });
        toast.present();  

        this.navCtrl.push(SignupPage, {merchantid : res.data , agent_id : this.agent_id});
      }
      });
    }
    else {
      let toast = this.toastCtrl.create({
        message: 'Please fill all fields',
        duration: 3000,
        position: 'top'
      });
      toast.present();
    }
  }

}
