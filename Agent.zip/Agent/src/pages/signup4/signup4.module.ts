import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Signup4Page } from './signup4';

@NgModule({
  declarations: [
    Signup4Page,
  ],
  imports: [
    IonicPageModule.forChild(Signup4Page),
  ],
})
export class Signup4PageModule {}
