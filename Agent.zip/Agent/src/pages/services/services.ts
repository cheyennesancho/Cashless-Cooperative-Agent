import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Signup2Page } from '../signup2/signup2';
import { AfpPage } from '../afp/afp';
import { FreeadsPage } from '../freeads/freeads';

/**
 * Generated class for the ServicesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-services',
  templateUrl: 'services.html',
})
export class ServicesPage {
  
  private merchantid : any;
  private agent_id : any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.merchantid = this.navParams.get('merchantid');
    this.agent_id = this.navParams.get('agent_id');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ServicesPage');
  }

  openBlacksheep(){
    this.navCtrl.push(Signup2Page, {merchantid : this.merchantid , agent_id : this.agent_id});
  };
  
  openAFP(){
    this.navCtrl.push(AfpPage, {merchantid : this.merchantid , agent_id : this.agent_id});
  }
  
  openAds(){
    this.navCtrl.push(FreeadsPage, {merchantid : this.merchantid, agent_id : this.agent_id });
  }

}
