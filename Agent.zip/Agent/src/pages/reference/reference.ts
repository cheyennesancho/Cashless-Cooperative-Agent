import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers/user/user';

/**
 * Generated class for the ReferencePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reference',
  templateUrl: 'reference.html',
})
export class ReferencePage {

  private agent_id : any;
  private email : string;
  private merchantid : number;
  private knowEmail : boolean = true;
  private knowName : boolean;
  private knowDBA : boolean;
  private referralEmail : string = '';
  private referralName : string = '';
  private referralDBA : string = '';
  private referralAddress : string = '';
  private referralCity : string = '';
  private referralState : string = '';
  private referralZipcode : string = '';
  private referralPhone : number;
  public states : any = [ "Alaska",
                          "Alabama",
                          "Arkansas",
                          "American Samoa",
                          "Arizona",
                          "California",
                          "Colorado",
                          "Connecticut",
                          "District of Columbia",
                          "Delaware",
                          "Florida",
                          "Georgia",
                          "Guam",
                          "Hawaii",
                          "Iowa",
                          "Idaho",
                          "Illinois",
                          "Indiana",
                          "Kansas",
                          "Kentucky",
                          "Louisiana",
                          "Massachusetts",
                          "Maryland",
                          "Maine",
                          "Michigan",
                          "Minnesota",
                          "Missouri",
                          "Mississippi",
                          "Montana",
                          "North Carolina",
                          " North Dakota",
                          "Nebraska",
                          "New Hampshire",
                          "New Jersey",
                          "New Mexico",
                          "Nevada",
                          "New York",
                          "Ohio",
                          "Oklahoma",
                          "Oregon",
                          "Pennsylvania",
                          "Puerto Rico",
                          "Rhode Island",
                          "South Carolina",
                          "South Dakota",
                          "Tennessee",
                          "Texas",
                          "Utah",
                          "Virginia",
                          "Virgin Islands",
                          "Vermont",
                          "Washington",
                          "Wisconsin",
                          "West Virginia",
                          "Wyoming"];
                        

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl : ToastController,
              public user : User,
            ) {
              this.agent_id = this.navParams.get('agent_id');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReferencePage');
  }

  checkEmail(){
    if(this.email != ""){
      let type = "?type=checkemail&email=" + this.email;
      this.user.reference(type).subscribe((res : any)=>{
        console.log(res);
        if(res.status == 1){
          this.merchantid = res.data;
        }
        else{
          let toast = this.toastCtrl.create({
            message: res.message,
            duration: 3000,
            position: 'top'
          });
          toast.present();              
        };
      });
    };
  }

  submitReference(){
    let type = "?type=reference" 
                + "&agentid=" + this.agent_id
                + "&merchantid=" + this.merchantid
                + "&referralEmail=" + this.referralEmail
                + "&referralDBA=" + this.referralDBA
                + "&referralName=" + this.referralName
                + "&referralAddress=" + this.referralAddress
                + "&referralCity=" + this.referralCity
                + "&referralState=" + this.referralState
                + "&referralZipcode=" + this.referralZipcode
                + "&referralPhone=" + this.referralPhone

    console.log(type);
    this.user.reference(type).subscribe((res : any)=>{
      console.log(res);
      if(res.status == 1){
        let toast = this.toastCtrl.create({
          message: 'Referred Successfully',
          duration: 3000,
          position: 'top'
        });
        toast.present();              
        this.navCtrl.pop();
      }
      else{
        let toast = this.toastCtrl.create({
          message: res.message,
          duration: 3000,
          position: 'top'
        });
        toast.present();              
      };
    });

  }


}
