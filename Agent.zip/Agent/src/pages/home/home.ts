import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, ToastController, NavParams, LoadingController, Platform } from 'ionic-angular';
import {SignaturePad} from 'angular2-signaturepad/signature-pad';
import { HttpClient, HttpParams,HttpHeaders} from '@angular/common/http';
import { ServicesPage } from '../services/services';
import { User } from '../../providers/user/user';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { Camera, CameraOptions } from '@ionic-native/camera';

/**
 * Generated class for the HomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  @ViewChild(SignaturePad) public signaturePad : SignaturePad;
  public signaturePadOptions : Object = {
    'minWidth': 2,
    'backgroundColor': "white",
    'canvasWidth': 340,
    'canvasHeight': 200
  };
  public signatureImage : string;
  private sameAdd : any;
  private showSignature : any;
  private imageURI:any;
  private imageFileName:any;
  private info : {
                  accName : string,
                  compName : string,
                  compDBA : string,
                  compAddress : string,
                  compCity : string,
                  compState : string,
                  compZip : number,
                  compPhone : number ,
                  compEmail : string,
                  compFax : number,
                  phyAddress : string,
                  phyCity : string,
                  phyState : string,
                  phyZip : number,
                  dbaPhone : number,
                  password : string,
                  EIN : string,
                  ssn : number,
                  industry : string,
                  website : string,
                  bankAccName : string,
                  accNum : number,
                  routNum : number,
                  agreeTerms : boolean,
                  IRSName : string,
                  signature : any,

                  } = {
                    accName : "",
                    compName : "",
                    compDBA : "",
                    compAddress : "",
                    compCity : "",
                    compState : "",
                    compZip : null,
                    compPhone : null ,
                    compEmail : "",
                    compFax : null,
                    phyAddress : "" ,
                    phyCity : "",
                    phyState : "",
                    phyZip : null,
                    dbaPhone : null,
                    password : "",
                    EIN : "",
                    ssn : null,
                    industry : "",
                    website : "",
                    bankAccName : "",
                    accNum : null,
                    routNum : null,
                    agreeTerms : false,
                    IRSName : "",
                    signature : undefined,
                  
         };

  public industries :any ;
  public confirmPass : string;
  public agent_id : string;
  public states : any = ["Alaska",
  "Alabama",
  "Arkansas",
  "American Samoa",
  "Arizona",
  "California",
  "Colorado",
  "Connecticut",
  "District of Columbia",
  "Delaware",
  "Florida",
  "Georgia",
  "Guam",
  "Hawaii",
  "Iowa",
  "Idaho",
  "Illinois",
  "Indiana",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Massachusetts",
  "Maryland",
  "Maine",
  "Michigan",
  "Minnesota",
  "Missouri",
  "Mississippi",
  "Montana",
  "North Carolina",
  " North Dakota",
  "Nebraska",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "Nevada",
  "New York",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Puerto Rico",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Virginia",
  "Virgin Islands",
  "Vermont",
  "Washington",
  "Wisconsin",
  "West Virginia",
  "Wyoming"]

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public http : HttpClient,
              public toastCtrl : ToastController,
              public loadingCtrl : LoadingController,
              private transfer: FileTransfer,
              private camera: Camera,
              private platform : Platform,
              private user : User,

            ) {
               this.industries = ["Accounting/Finance" ,
                        "Advertising/Public Relations" ,
                        "Arts/Entertainment/Publishing",
                        "Automotive",
                        "Business Development",
                        "Clerical/Administrative",
                        "Construction/Facilities",
                        "Consumer Goods",
                        "Customer Service",
                        "Education/Training",
                        "Gasoline/Convenience Store",
                        "Green",
                        "Grocery",
                        "Healthcare",
                        "Hospitality/Travel",
                        "Installation/Maintenance",
                        "Law Enforcement/Security",
                        "Legal",
                        "Marketing",
                        "Non-Profit/Volunteer",
                        "Professional Services",
                        "QA/Quality Control",
                        "Restaurant/Food Service",
                        "Retail",
                        "Sales",
                        "Skilled Labor",
                        "Technology",
                        "Telecommunications",
                        "Transportation/Logistics",
                        "Other"
               ];

               this.agent_id = this.navParams.get('agent_id');
               let x = this.platform.width();
               console.log(x);     
               this.signaturePadOptions = {
                'minWidth': 2,
                'backgroundColor': "white",
                'canvasWidth': x,
                'canvasHeight': (10*x)/16
              };
                  

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Signup5Page');
    this.signaturePad.clear();
  }

  changeAdd(){
    if(this.sameAdd == true){
      this.info.phyAddress = this.info.compAddress;
      this.info.phyCity = this.info.compCity;
      this.info.phyState = this.info.compState;
      this.info.phyZip = this.info.compZip;
    };
    if(this.sameAdd == false){
      this.info.phyAddress = "";
      this.info.phyCity = "";
      this.info.phyState = "";
      this.info.phyZip = null;
    };
  }

  doSubmit(){
    this.signatureImage = this.signaturePad.toDataURL();
    this.info.signature = this.signatureImage;
    this.showSignature = 1;

    console.log(this.signatureImage);
    if(this.signatureImage) {
      if(this.info.accName != "" &&
      this.info.compName != "" &&
      this.info.compDBA != "" &&
      this.info.compAddress != "" &&
      this.info.compCity != "" &&
      this.info.compState != "" &&
      this.info.compZip != null &&
      this.info.compPhone != null &&
      this.info.compEmail != "" &&
      this.info.phyAddress != "" &&
      this.info.phyCity != "" &&
      this.info.phyState != "" &&
      this.info.phyZip != null &&
      this.info.dbaPhone != null &&
      this.info.password != "" &&
      this.info.industry != "" &&
      this.info.bankAccName != "" &&
      this.info.IRSName != "" &&
      this.info.accNum != null &&
      this.info.routNum != null &&
      this.info.signature != undefined 
      ) {
        if( this.imageURI != undefined ) {
          this.uploadFile();
        };
        let type = "agent_id=" + this.agent_id +
        "&accName=" + this.info.accName +
        "&compName=" + this.info.compName +
        "&compDBA=" + this.info.compDBA +
        "&compAddress=" + this.info.compAddress +
        "&compCity=" + this.info.compCity + 
        "&compState=" + this.info.compState + 
        "&compZip=" + this.info.compZip + 
        "&compPhone=" + this.info.compPhone +
        "&compEmail=" + this.info.compEmail +
        "&compFax=" + this.info.compFax +
        "&phyAddress=" + this.info.phyAddress +
        "&phyCity=" + this.info.phyCity +
        "&phyState=" + this.info.phyState +
        "&phyZip=" + this.info.phyZip + 
        "&dbaPhone=" + this.info.dbaPhone + 
        "&password=" + this.info.password +
        "&EIN=" + this.info.EIN + 
        "&ssn=" + this.info.ssn +
        "&IRSName=" + this.info.IRSName +
        "&industry=" + this.info.industry +
        "&website=" + this.info.website +
        "&bankAccName=" + this.info.bankAccName + 
        "&accNum=" + this.info.accNum + 
        "&routNum=" + this.info.routNum + 
        "&agreeTerms=" + this.info.agreeTerms +
        "&signature=" + this.info.signature;
        console.log(JSON.stringify(this.info)); 
          if(this.info.password == this.confirmPass){
            this.user.register(type).subscribe((res : any) =>{
            console.log(res);
              if(res.status == 1 ){
                let toast = this.toastCtrl.create({
                  message: 'Registration Success.',
                  duration: 3000,
                  position: 'bottom'
                });
                toast.present();  
                this.navCtrl.push(ServicesPage, {merchantid : res.data});
              }
            });
          } else {
            let toast = this.toastCtrl.create({
              message: 'Passwords does not match',
              duration: 3000,
              position: 'top'
            });
            toast.present();  
          }
      } else {
        let toast = this.toastCtrl.create({
          message: 'Please fill all fields',
          duration: 3000,
          position: 'top'
        });
        toast.present();
      };
    };
  }

  drawClear(){
    this.signaturePad.clear();
  }

  selectFile(){
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }
  
    this.camera.getPicture(options).then((imageData) => {
      this.imageURI = imageData;
    }, (err) => {
      console.log(err);
      this.presentToast(this.imageURI);
    });
  
  }

  
  uploadFile() {
    let loader = this.loadingCtrl.create({
      content: "Uploading..."
    });
    loader.present();
    const fileTransfer: FileTransferObject = this.transfer.create();
  
    let options: FileUploadOptions = {
      fileKey: 'ionicfile',
      fileName: 'ionicfile',
      chunkedMode: false,
      mimeType: "image/jpeg",
      headers: {}
    }
  
    fileTransfer.upload(this.imageURI, 'https://freedomchoiceglobal.com/blacksheep/api/ads.php', options)
      .then((data) => {
      console.log(data+" Uploaded Successfully");
      this.imageFileName = data;
      loader.dismiss();
      this.presentToast("Image uploaded successfully");
    }, (err) => {
      console.log(err);
      loader.dismiss();
      this.presentToast(err);
    });
  }

  presentToast(msg) {
    let toast = this.toastCtrl.create({
      message: msg,
      duration: 3000,
      position: 'bottom'
    });
  
    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });
  
    toast.present();
  }

}
