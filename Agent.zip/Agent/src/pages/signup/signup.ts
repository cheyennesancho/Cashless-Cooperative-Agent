import { Component } from '@angular/core';
import { IonicPage, NavController, ToastController,NavParams } from 'ionic-angular';
import { User } from '../../providers/user/user';
import { ToolPage } from '../tool/tool';
import { Signup2Page } from '../signup2/signup2';
import { HttpClient, HttpParams,HttpHeaders} from '@angular/common/http';
import { HomePage } from '../home/home';
import { ServicesPage } from '../services/services';
import { LoginPage } from '../login/login';
import { ReferencePage } from '../reference/reference';

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html'
})
export class SignupPage {
  // The account fields for the login form.
  // If you're using the username field with or without email, make
  // sure to add it to the type
    private passwordConfirm: string;
    public savings;
    private agent_id;
    private page : any;

    constructor(public navCtrl: NavController,
                public user: User,
                public toastCtrl: ToastController,public http: HttpClient,
                public navParams: NavParams,
                ) {
        this.agent_id = this.navParams.get('agent_id');

  }


    
  openReg(){
      this.navCtrl.push(HomePage , {agent_id : this.agent_id} );
  };

  openServices(){
      this.navCtrl.push(ServicesPage , {agent_id : this.agent_id} );
  };

  openTool(){
      this.navCtrl.push(ToolPage , {agent_id : this.agent_id} );
  };

  openReference(){
    this.navCtrl.push(ReferencePage , {agent_id : this.agent_id} );
  }


  doLogout(){
    this.navCtrl.setRoot(LoginPage);
  }
}


       


  

