import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FreeadsPage } from './freeads';

@NgModule({
  declarations: [
    FreeadsPage,
  ],
  imports: [
    IonicPageModule.forChild(FreeadsPage),
  ],
})
export class FreeadsPageModule {}
