import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController } from 'ionic-angular';
import { User } from '../../providers/user/user';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { SignupPage } from '../signup/signup';


@IonicPage()
@Component({
  selector: 'page-freeads',
  templateUrl: 'freeads.html',
})
export class FreeadsPage {
  
  private merchantid : any ;
  private imageURI:any;
  private imageFileName:any;
  private agent_id : string;
  private email : string;
  private proofingEmail : string;
  private checking : any = [] ;
  private zipCodes : any = ['37421',
                            '37411',
                            '37413',
                            '44114',
                            '32771',
                            '44115'
                          ];
  private  zipcodeList : any = [];
  private contractLength : number;
  private agreedTerms : boolean = false;


  constructor(public navCtrl: NavController,
              public toastCtrl : ToastController,
              public loadingCtrl : LoadingController,
              public navParams: NavParams,
              private transfer: FileTransfer,
              private camera: Camera,
              public user : User
            ) {

    this.merchantid = this.navParams.get('merchantid');
    this.agent_id = this.navParams.get('agent_id');
    for(let i = 0 ; i < this.zipCodes.length ; i++){
      let x = { i : false };
      this.checking.push(false);
    }
    console.log(this.checking);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FreeadsPage');
  }

  checkEmail(){
    if(this.email != ""){
      let type = "email=" + this.email;
      this.user.checkEmail(type).subscribe((res : any)=>{
        console.log(res);
        if(res.status == 1){
          this.merchantid = res.data;
        };
      });
    };
  };

  onSubmit(){
    if(this.merchantid != '' &&
        this.zipcodeList != [] &&
        this.agreedTerms != false &&
        this.proofingEmail != ''
      ){
        if( this.imageURI != undefined ) {
          this.uploadFile();
        }
  
    let type = "type=signup" +
      "&merchantid=" + this.merchantid +
      "&agent_id=" + this.agent_id +
      "&locations=" + this.zipcodeList + 
      "&proofingEmail=" + this.proofingEmail +
      "&agreedTerms=" + this.agreedTerms;

      this.user.enrollAds(type).subscribe((res: any) =>{
        console.log(res);
        if(res.status == 1 ){
  
        let toast = this.toastCtrl.create({
          message: 'Registration Success.',
          duration: 3000,
          position: 'bottom'
        });
        toast.present();  
  
        this.navCtrl.push(SignupPage, {merchantid : res.data , agent_id : this.agent_id});
      };
      });
    }
  }

  addZip( check , item){
    console.log(check);
    // console.log('checked');
  if( check == true){
      this.zipcodeList.push(item);
      console.log(this.zipcodeList);
  }
  if( check == false){
    var index = this.zipcodeList.indexOf(item);
    if (index !== -1) {this.zipcodeList.splice(index, 1)};

    // this.zipcodeList.pop(item);
    console.log(this.zipcodeList);
}

  }

  selectFile(){
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }
  
    this.camera.getPicture(options).then((imageData) => {
      this.imageURI = imageData;
    }, (err) => {
      console.log(err);
      this.presentToast(err);
    });
  
  }

  
  uploadFile() {
    let loader = this.loadingCtrl.create({
      content: "Uploading..."
    });
    loader.present();
    const fileTransfer: FileTransferObject = this.transfer.create();
  
    let options: FileUploadOptions = {
      fileKey: 'ionicfile',
      fileName: 'ionicfile',
      chunkedMode: false,
      mimeType: "image/jpeg",
      headers: {}
    }
  
    fileTransfer.upload(this.imageURI, 'https://freedomchoiceglobal.com/blacksheep/api/ads.php', options)
      .then((data) => {
      console.log(data+" Uploaded Successfully");
      this.imageFileName = data;

      loader.dismiss();
      this.presentToast("Image uploaded successfully");
    }, (err) => {
      console.log(err);
      loader.dismiss();
      this.presentToast(err);
    });
  }

  presentToast(msg) {
    let toast = this.toastCtrl.create({
      message: msg,
      duration: 3000,
      position: 'bottom'
    });
  
    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });
  
    toast.present();
  }
  

}
