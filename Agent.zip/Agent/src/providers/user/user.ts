
import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
// import {Headers, RequestOptions} from '@angular/http';

@Injectable()
export class User {
  _user: any;

      private databasecreds = {
        username: "gynesus_it",
        password: "byGod1919!!",
          };
  sheepApi = "https://freedomchoiceglobal.com/blacksheep/api/user.php";
  calcApi = "https://freedomchoiceglobal.com/blacksheep/api/calc.php";
  freedomchoice = "http://admin.freedomchoiceglobal.com/api/enroll_merchants.php";
  blacksheep = "https://freedomchoiceglobal.com/blacksheep/api/blacksheep.php";
  pff = "https://freedomchoiceglobal.com/blacksheep/api/pff.php";
  ads = "https://freedomchoiceglobal.com/blacksheep/api/ads.php";
  refer = "https://freedomchoiceglobal.com/blacksheep/api/referral.php";

  constructor(public http: HttpClient ) { }

  checkEmail(type){
    return this.http.get(this.blacksheep + "?type=email&" + type );
  }
  
  register(type){
    console.log(JSON.stringify(type));
    return this.http.post(this.freedomchoice  , type , {headers  : {'Content-Type': 'application/x-www-form-urlencoded'} });  
  }
  
  Enrollservice(type){
    console.log(type);
    console.log(JSON.stringify(type));

    return this.http.post(this.blacksheep , type, {headers  : {'Content-Type': 'application/x-www-form-urlencoded'} })
  }

  enrollPaper(type) {
    console.log(type);
    return this.http.post(this.pff , type, {headers  : {'Content-Type': 'application/x-www-form-urlencoded'} })
  }
  
  enrollAds(type) {
    console.log(type);
    return this.http.post(this.ads , type, {headers  : {'Content-Type': 'application/x-www-form-urlencoded'} })
  }
  

  login(type) {
    console.log("in service" + type);
    return this.http.get(this.sheepApi + type );

  }

  reference(type){
    return this.http.get(this.refer + type);
  }
  

  updateProfile(type){
   console.log("Hit Profile Update");
   return this.http.post(this.sheepApi + type, JSON.stringify(this.databasecreds), )

  }

  profile(type) {
    console.log("Profile type :" + type);
    return this.http.post(this.sheepApi + type, JSON.stringify(this.databasecreds), )

  }
  calculate(type) {
    console.log("in service" + type);
    return this.http.post(this.calcApi + type, "");

  }

  calculations(type) {
    console.log("Calculations for : " + type);
    return this.http.post(this.sheepApi+ type, "");
  }


}
