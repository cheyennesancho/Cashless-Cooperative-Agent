import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { SignaturePadModule } from 'angular2-signaturepad';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { Camera } from '@ionic-native/camera';

import { HttpClient,HttpClientModule  } from '@angular/common/http';
import { Http } from '@angular/http';

import {HomePage} from '../pages/home/home';
import { FreedomChoiceAgents } from './app.component';
import { SignupPage } from '../pages/signup/signup';
import { Signup2Page } from '../pages/signup2/signup2';
import { ToolPage } from '../pages/tool/tool';
import { User } from '../providers/user/user';
import { ServicesPage } from '../pages/services/services';

import { AfpPage } from '../pages/afp/afp';
import { FreeadsPage } from '../pages/freeads/freeads';
import { LoginPage } from '../pages/login/login';
import { ReferencePage } from '../pages/reference/reference';

@NgModule({
  declarations: [
    FreedomChoiceAgents,
    LoginPage,
    SignupPage,
    HomePage, 
    ServicesPage,
    ToolPage,
    Signup2Page,
    AfpPage,
    FreeadsPage,
    ReferencePage,

  ],
  imports: [
    BrowserModule, SignaturePadModule,
    HttpClientModule,
    IonicModule.forRoot(FreedomChoiceAgents)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    FreedomChoiceAgents,
    LoginPage,
    SignupPage,
    HomePage,
    ServicesPage,
    ToolPage,
    Signup2Page,
    AfpPage,
    FreeadsPage,
    ReferencePage
  ],
  providers: [
    User,
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    FileTransfer,
    FileTransferObject,
    File,
    Camera
  
  ]
})
export class AppModule {}
